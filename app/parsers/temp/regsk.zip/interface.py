import os
import sys
import subprocess
import json

def auto_interface(file,parser):
    try:
        CurrentPath=os.path.dirname(os.path.abspath(__file__))
        if(parser == "UserAssist"):    
            proc = subprocess.Popen('python3 "'+ CurrentPath+'/app/parsers/regsk/regsk.py" -k -f "' + file + '" -pl UserAssist' , shell=True ,stdout=subprocess.PIPE)

        data = proc.communicate()[0]
        print data
        return json.loads(data)

    except Exception as e:
        exc_type,exc_obj,exc_tb = sys.exc_info()
        msg = "[-] [Error] " + str(parser) + " Parser: " + str(exc_obj) + " - Line No. " + str(exc_tb.tb_lineno)
        print msg
        return (None , msg)
